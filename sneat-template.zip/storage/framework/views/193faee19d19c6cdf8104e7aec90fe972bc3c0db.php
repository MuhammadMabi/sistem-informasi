<div class="modal-body">
    <div class="row" id="edit-kelas">
        <table class="table">
            <tbody>
                <tr>
                    <td>NISN</td>
                    <td>:</td>
                    <td><?php echo e($siswa->nisn ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><?php echo e($siswa->nama ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td><?php echo e($siswa->jenis_kelamin ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e($siswa->tanggal_lahir ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($siswa->alamat ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Kelas</td>
                    <td>:</td>
                    <td>
                        <?php if($siswa->kelas_id == 'PSB'): ?>
                            PSB
                        <?php else: ?>
                            <?php echo e($siswa->kelas->kelas); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
</div>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/siswa/show.blade.php ENDPATH**/ ?>