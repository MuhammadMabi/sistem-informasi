

<?php $__env->startSection('title', 'Account settings - Account'); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <h5 class="card-header">Profile</h5>
                <hr class="my-0">
                <div class="card-body">
                    <form action="<?php echo e(route('update-profile')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        <input type="text" name="id" id="id" value="<?php echo e($akun->id); ?>" hidden>
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="nisn" class="form-label">NISN</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="nisn" name="nisn" value="<?php echo e($akun->siswa->nisn); ?>"
                                    placeholder="Enter your nisn" required autofocus>
                                <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="nama" class="form-label">Nama</label>
                                <input type="text" class="form-control" id="nama" name="nama"
                                    value="<?php echo e($akun->nama); ?>" placeholder="Enter your nama" required autofocus>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="email" name="email" value="<?php echo e($akun->email); ?>" placeholder="Enter your email"
                                    required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="jenis_kelamin">Jenis Kelamin</label>
                                <div class="">
                                    <?php if($akun->jenis_kelamin == 'Laki-laki'): ?>
                                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                                            value="Laki-laki" id="Laki-laki" checked />
                                        <label class="form-check-label" for="Laki-laki">
                                            Laki-laki
                                        </label>

                                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                                            value="Perempuan" id="Perempuan" />
                                        <label class="form-check-label" for="Perempuan">
                                            Perempuan
                                        </label>
                                    <?php else: ?>
                                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                                            value="Laki-laki" id="Laki-laki" />
                                        <label class="form-check-label" for="Laki-laki">
                                            Laki-laki
                                        </label>

                                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                                            value="Perempuan" id="Perempuan" checked />
                                        <label class="form-check-label" for="Perempuan">
                                            Perempuan
                                        </label>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir"
                                    value="<?php echo e($akun->tanggal_lahir); ?>" placeholder="Enter your tanggal_lahir" required>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="alamat">Alamat</label>
                                <input type="text" class="form-control" id="alamat" name="alamat"
                                    value="<?php echo e($akun->alamat); ?>" placeholder="Enter your alamat" required>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button class="btn btn-primary me-2" type="submit">Save
                                changes</button>
                            <a href="/dashboard"><button type="button" class="btn btn-secondary"
                                    data-bs-dismiss="modal">Back</button></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/auth/profile.blade.php ENDPATH**/ ?>