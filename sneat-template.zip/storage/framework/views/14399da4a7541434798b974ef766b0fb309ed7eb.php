

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('menu', 'dashboard'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Selamat Datang, <?php echo e(auth()->user()->nama); ?>!</h5>
                            <p class="mb-4">Untuk informasi terkait pelaksanaan PPDB Online dan memantau hasil seleksi akan
                                kami hubungi secepatnya.
                            </p>

                            
                        </div>
                    </div>
                    <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                            <img src="<?php echo e(asset('assets/img/illustrations/man-with-laptop-light.png')); ?>" height="140"
                                alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                data-app-light-img="illustrations/man-with-laptop-light.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 order-1">
            <div class="row">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($admin); ?></h3>
                            </div>
                            <br>
                            <span>Admin</span>
                        </div>
                        <span class="badge bg-label-dark rounded p-2">
                            <i class="bx bx-user bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($user); ?></h3>
                            </div>
                            <br>
                            <span>User</span>
                        </div>
                        <span class="badge bg-label-primary rounded p-2">
                            <i class="bx bx-group bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($kelas); ?></h3>
                            </div>
                            <br>
                            <span>Kelas</span>
                        </div>
                        <span class="badge bg-label-warning rounded p-2">
                            <i class="bx bx-box bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($guru); ?></h3>
                            </div>
                            <br>
                            <span>Guru</span>
                        </div>
                        <span class="badge bg-label-info rounded p-2">
                            <i class="bx bx-crown bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($siswa); ?></h3>
                            </div>
                            <br>
                            <span>Siswa</span>
                        </div>
                        <span class="badge bg-label-success rounded p-2">
                            <i class="bx bx-user-check bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-start justify-content-between">
                        <div class="content-left">
                            <div class="d-flex align-items-end mt-2">
                                <h3 class="mb-0 me-2"><?php echo e($psb); ?></h3>
                            </div>
                            <br>
                            <span>PSB</span>
                        </div>
                        <span class="badge bg-label-danger rounded p-2">
                            <i class="bx bx-user-voice bx-sm"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-12">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Profile Sekolah</h5>
                            <hr class="my-0">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>NPSN</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->npsn ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Nama</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->nama ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Status</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->status ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Email</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->email ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Nomor Telepon</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->no_telp ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Alamat</td>
                                            <td>:</td>
                                            <td><?php echo e($sekolah->alamat ?? '-'); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/dashboard.blade.php ENDPATH**/ ?>