

<?php $__env->startSection('title', 'Account settings - Account'); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <h5 class="card-header">Profile</h5>
                <hr class="my-0">
                <div class="card-body">
                    <div id="read"></div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            read();
        });

        function read() {
            $.get("<?php echo e(url('/profile/read')); ?>", {}, function(kelas, status) {
                $("#read").html(kelas);
            });
        }

        function update(id) {
            let nisn = $('#nisn').val();
            let nama = $('#nama').val();
            let email = $('#email').val();
            let jenis_kelamin = $('.jenis_kelamin').val();
            let tanggal_lahir = $('#tanggal_lahir').val();
            let alamat = $('#alamat').val();
            let token = $("meta[name='csrf-token']").attr("content");

            $.ajax({

                url: `/update-profile`,
                type: "PUT",
                cache: false,
                data: {
                    "id": id,
                    "nisn": nisn,
                    "nama": nama,
                    "email": email,
                    "jenis_kelamin": jenis_kelamin,
                    "tanggal_lahir": tanggal_lahir,
                    "alamat": alamat,
                    "_token": token
                },
                success: function(response) {
                    swal({
                        title: `Success!`,
                        text: response.message,
                        icon: "success",
                        buttons: {
                            cancel: false,
                            confirm: true,
                        },
                        dangerMode: false,
                    })

                    // $('#nisn').val();
                    // $('#nama').val();
                    // $('#email').val();
                    // $('.jenis_kelamin').val();
                    // $('#tanggal_lahir').val();
                    // $('#alamat').val();
                },

                error: function(response) {
                    $('#nisn').val(nisn);
                    $('#nama').val(nama);
                    $('#email').val(email);
                    $('.jenis_kelamin').val(jenis_kelamin);
                    $('#tanggal_lahir').val(tanggal_lahir);
                    $('#alamat').val(alamat);

                    $.each(response.responseJSON.errors, function(key, value) {
                        $('#' + key).addClass('is-invalid')
                        $('.alert-' + key).removeClass('d-none')
                        $('.alert-' + key).append("<p>" + value + "</p>")
                    })
                }

            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/auth/profile/profile.blade.php ENDPATH**/ ?>