<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

</head>

<body>
    <table class="table" id="example">
        <thead>
            <tr>
                <th width="10%">No</th>
                <th>Kelas</th>
                <th>Wali Kelas</th>
                <?php if(auth()->user()->role == 'Admin'): ?>
                    <th>Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody id="table-post">
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($k->kelas); ?></td>
                    <td><?php echo e($k->guru->nama); ?></td>
                    <?php if(auth()->user()->role == 'Admin'): ?>
                        <td>
                            <a style="color: inherit" href="javascript:void(0)" id="btn-edit-post"
                                data-id="<?php echo e($k->id); ?>" onclick="show(<?php echo e($k->id); ?>)"><i class="bx bx-edit-alt me-1"></i></a>
                            <a style="color: inherit" href="javascript:void(0)" id="btn-delete-post"
                                data-id="<?php echo e($k->id); ?>" onclick="destroy(<?php echo e($k->id); ?>)"><i class="bx bx-trash me-1"></i></a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


    <script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/kelas/read.blade.php ENDPATH**/ ?>