<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <title>Sistem Informasi Sekolah</title>

    <!-- Bootstrap core CSS -->
    <link href="/landingpage/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="/landingpage/assets/css/fontawesome.css">
    <link rel="stylesheet" href="/landingpage/assets/css/templatemo-digimedia-v3.css">
    <link rel="stylesheet" href="/landingpage/assets/css/animated.css">
    <link rel="stylesheet" href="/landingpage/assets/css/owl.css">

    <style>
        #sis {
            position: relative;
            left: auto;
            margin-top: 35px;
            /* margin-right: 100px; */
            /* width: 100px;
            height: 120px; */
            /* border: 3px solid blue; */
        }
    </style>
    <!--

TemplateMo 568 DigiMedia

https://templatemo.com/tm-568-digimedia

-->
</head>

<body>

    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
        <div class="preloader-inner">
            <span class="dot"></span>
            <div class="dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Pre-header Starts -->
    
    <!-- Pre-header End -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.html" class="logo">
                            
                            <h5 id="sis">S I S</h5>
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                            <li class="scroll-to-section"><a href="#about">About</a></li>
                            
                            <li class="scroll-to-section">
                                <div class="border-first-button"><a href="/login">Sign In</a></div>
                            </li>
                        </ul>
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6 align-self-center">
                            <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s"
                                data-wow-delay="1s">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h2>Penerimaan Peserta Didik Baru</h2>
                                        <p>Website ini digunakan oleh masyarakat dan calon siswa untuk pendaftaran penerimaan peserta didik baru dan mendapatkan informasi terkait pelaksanaan PPDB Online, termasuk memantau hasil seleksi. ingin mendaftar PPDB? klik button dibawah ini!
                                        </p>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="border-first-button scroll-to-section">
                                            <a href="/register">Sign Up</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                                <img src="/landingpage/assets/images/slider-dec-v3.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="about" class="about section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="about-left-image  wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                                <img src="/landingpage/assets/images/about-dec-v3.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-6 align-self-center  wow fadeInRight" data-wow-duration="1s"
                            data-wow-delay="0.5s">
                            <div class="about-right-content">
                                <div class="section-heading">
                                    <h6>About</h6>
                                    <h4>Sistem Informasi <em>Sekolah</em></h4>
                                    <div class="line-dec"></div>
                                </div>
                                <p>Sistem Informasi Sekolah adalah sebuah sarana atau alat yang bisa digunakan oleh
                                    sekolah untuk meningkatkan pelayanan dan kualitas sekolah. Melalui sistem ini, pihak
                                    sekolah bisa berinteraksi dengan banyak pihak terkait. Seperti calon siswa,
                                    masyarakat, siswa, orang tua, dan lain-lain.</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    

    

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright © 2023 Maybe Dev Company. All Rights Reserved.
                        <br>Design: <a href="https://instagram.com/mbiplx" target="_blank"
                            title="free css templates">Muhammad Mabi</a>
                    </p>
                </div>
            </div>
        </div>
    </footer>


    <!-- Scripts -->
    <script src="/landingpage/vendor/jquery/jquery.min.js"></script>
    <script src="/landingpage/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/landingpage/assets/js/owl-carousel.js"></script>
    <script src="/landingpage/assets/js/animation.js"></script>
    <script src="/landingpage/assets/js/imagesloaded.js"></script>
    <script src="/landingpage/assets/js/custom.js"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/landingpage.blade.php ENDPATH**/ ?>