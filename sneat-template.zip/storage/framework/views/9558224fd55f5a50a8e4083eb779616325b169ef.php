<div class="modal-body">
    <div class="row" id="edit-kelas">
        <div class="demo-vertical-spacing demo-only-element col-md-12 ">
            <div class="form-password-toggle">
                <label class="form-label" for="nisn">NISN</label>
                <input type="text" value="<?php echo e($siswa->id); ?>" name="id" hidden>
                <input type="number" class="form-control" id="nisn" name="nisn"
                    aria-describedby="basic-default-password2" required value="<?php echo e($siswa->nisn); ?>" />
                <span class="invalid-feedback alert-nisn d-none" role="alert"></span>
            </div>
            <div class="form-password-toggle">
                <label class="form-label" for="nama">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama"
                    aria-describedby="basic-default-password2" required value="<?php echo e($siswa->nama); ?>" />
                <span class="invalid-feedback alert-nama d-none" role="alert"></span>
            </div>
            <div class="form-password-toggle">
                <label class="form-label" for="jenis_kelamin">Jenis Kelamin</label>
                <div class="">
                    <?php if($siswa->jenis_kelamin == 'Laki-laki'): ?>
                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                            value="Laki-laki" id="Laki-laki" checked />
                        <label class="form-check-label" for="Laki-laki">
                            Laki-laki
                        </label>

                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                            value="Perempuan" id="Perempuan" />
                        <label class="form-check-label" for="Perempuan">
                            Perempuan
                        </label>
                    <?php else: ?>
                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                            value="Laki-laki" id="Laki-laki" />
                        <label class="form-check-label" for="Laki-laki">
                            Laki-laki
                        </label>

                        <input name="jenis_kelamin" class="form-check-input jenis_kelamin" type="radio"
                            value="Perempuan" id="Perempuan" checked />
                        <label class="form-check-label" for="Perempuan">
                            Perempuan
                        </label>
                    <?php endif; ?>
                    <span class="invalid-feedback alert-jenis_kelamin d-none" role="alert"></span>
                </div>
            </div>
            <div class="form-password-toggle">
                <label class="form-label" for="tanggal_lahir">Tanggal Lahir</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir"
                    aria-describedby="basic-default-password2" required value="<?php echo e($siswa->tanggal_lahir); ?>" />
                <span class="invalid-feedback alert-tanggal_lahir d-none" role="alert"></span>
            </div>
            <div class="form-password-toggle">
                <label class="form-label" for="alamat">alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" required><?php echo e($siswa->alamat); ?></textarea>
                <span class="invalid-feedback alert-alamat d-none" role="alert"></span>
            </div>
            <div class="form-password-toggle">
                <label class="form-label" for="alamat">Kelas</label>
                <select class="form-select" id="kelas_id" required name="kelas_id">
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($siswa->kelas_id == $k->id): ?>
                            <option value="<?php echo e($k->id); ?>" selected><?php echo e($k->kelas); ?>

                            </option>
                        <?php endif; ?>
                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($siswa->kelas_id == 'PSB'): ?>
                        <option value="PSB" selected>Penerimaan Siswa Baru (PSB)</option>
                    <?php else: ?>
                        <option value="PSB">Penerimaan Siswa Baru (PSB)</option>
                    <?php endif; ?>
                </select>
                <span class="invalid-feedback alert-kelas_id d-none" role="alert"></span>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button class="btn btn-primary" onclick="update(<?php echo e($siswa->id); ?>)">Save
        changes</button>
</div>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/siswa/edit.blade.php ENDPATH**/ ?>