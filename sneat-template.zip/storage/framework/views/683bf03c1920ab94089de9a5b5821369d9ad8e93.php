<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

    <!-- ! Hide app brand if navbar-full -->
    <div class="app-brand demo">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo ms-5">
                <?php echo $__env->make('_partials.macros', ['width' => 25, 'withbg' => '#696cff'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </span>
            <span class="app-brand-text demo fw-bold ms-2 ms-4">S I S</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-autod-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">

        

        <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'dashboard' ? 'active' : ''); ?>">
            <a href="/dashboard" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div>Dashboard</div>
            </a>
        </li>
        <?php if(auth()->user()->role == 'Admin'): ?>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'sekolah' ? 'active' : ''); ?>">
                <a href="/sekolah" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-cube-alt"></i>
                    <div>Sekolah</div>
                </a>
            </li>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'user' ? 'active' : ''); ?>">
                <a href="/user" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user"></i>
                    <div>User</div>
                </a>
            </li>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'guru' ? 'active' : ''); ?>">
                <a href="/guru" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-crown"></i>
                    <div>Guru</div>
                </a>
            </li>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'siswa' ? 'active' : ''); ?>">
                <a href="/siswa" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-group"></i>
                    <div>Siswa</div>
                </a>
            </li>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'kelas' ? 'active' : ''); ?>">
                <a href="/kelas" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-box"></i>
                    <div>Kelas</div>
                </a>
            </li>
        <?php endif; ?>
        <?php if(auth()->user()->role == 'Siswa'): ?>
            <li class="menu-item <?php echo e(e($__env->yieldContent('menu')) == 'kelas-siswa' ? 'active' : ''); ?>">
                <a href="/kelas-siswa" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-box"></i>
                    <div>Kelas</div>
                </a>
            </li>
        <?php endif; ?>

        
    </ul>

</aside>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>