<div class="modal-body">
    <div class="row" id="edit-kelas">
        <table class="table">
            <tbody>
                <tr>
                    <td>NIP</td>
                    <td>:</td>
                    <td><?php echo e($guru->nip ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><?php echo e($guru->nama ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td><?php echo e($guru->jenis_kelamin ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e($guru->tanggal_lahir ?? '-'); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($guru->alamat ?? '-'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
</div>
<?php /**PATH C:\xampp\htdocs\sneat-template\resources\views/guru/show.blade.php ENDPATH**/ ?>